"""Delfos NL2SQL Pipeline."""

__version__ = "0.1.0"
