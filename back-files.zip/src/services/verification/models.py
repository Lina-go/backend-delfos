"""Verification service models.

The main VerificationResult is in verification_result.py.
"""
