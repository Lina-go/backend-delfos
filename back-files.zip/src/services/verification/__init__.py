"""Verification service module."""
