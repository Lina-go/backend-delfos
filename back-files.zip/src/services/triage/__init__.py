"""Triage service module."""
