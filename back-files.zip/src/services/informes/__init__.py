from src.services.informes.service import InformeService

__all__ = ["InformeService"]
