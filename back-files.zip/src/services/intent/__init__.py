"""Intent service module."""
