"""Configuration module."""
