"""Integration tests module."""
